import PlaygroundSupport
import UIKit

//------------------------Section #1------------------------
class start: UITableViewController {
    //MARK: Init Code
    override func viewDidLoad() {
        //general look and feel of app
        title = "Swif-cyclopedia!"
        tableView.separatorStyle = .none
        self.navigationItem.setHidesBackButton(true, animated:true)
        tableView.backgroundColor = .systemBlue
        self.tableView.contentInset = UIEdgeInsets(top: 50, left: 0, bottom: 0, right: 0)
        
        //ui image
        let imageName1 = UIImage(named: "Squares.png")
        let imageView1 = UIImageView(image: imageName1)
        imageView1.frame = CGRect(x: 243, y: 475, width: 257, height: 193)
        view.addSubview(imageView1)
        
        //text for context
        let imageText = UILabel()
        imageText.text = "Click on the button below to learn more!"
        imageText.sizeToFit()
        imageText.font = UIFont.preferredFont(forTextStyle: .body)
        imageText.textAlignment = .center
        imageText.frame = CGRect(x: 100, y: 100, width: 400, height: 260)
        imageText.center = CGPoint(x: view.frame.midX-145, y: -25)
        imageText.numberOfLines = 23
        imageText.textColor = .white
        self.view.addSubview(imageText)
        
        //button to start plot and app
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
        button.backgroundColor = .blue
        button.center = CGPoint(x: view.frame.midX-125, y: view.frame.midY-125)
        button.setTitle("Click here to start your journey!", for: .normal)
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
        
        
    }
    //main titles for tableview
    let titles = ["Variable Declaration! 🤔", "Conditional Statements! 🤩", "Functions! 🤓", "Lists [ ] 🤯", "Recursion 🤨"]
    
    //small descriptions
    let inDepth = ["Let's declare 'variables'!", "Let's see how to compare data!", "Lets see how we can organize code!", "Let's see how we can store many pieces of information in one place!", "Lets see how we can break down code to solve complex problems!"]
    
    //button action code, object function
    @objc func buttonAction(){
        
        let detail = number2()
        navigationController?.pushViewController(detail, animated: true)
    }
    
    
    //tell app number of cells
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titles.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // attempt to dequeue a cell
        var cell: UITableViewCell!
        cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        if cell == nil {
            // none to dequeue – make a new one
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")
            cell?.accessoryType = .disclosureIndicator
            
        }
        
        // configure cell here
        
        let title2 = titles[indexPath.row]
        let indepth2 = inDepth[indexPath.row]
        cell.detailTextLabel?.text = "\(indepth2)"
        cell.textLabel?.text = "#\(indexPath.row+1): \(title2)"
        
        return cell
        
    }
    //tableview action, left nil
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard (tableView.cellForRow(at: indexPath)?.detailTextLabel?.text) != nil else { return }
        
    }
    
}


//------------------------Section #2------------------------
class number2: UIViewController{
    //falling text list
    let extraInDepth = [
        "Let's declare 'variables'! Variables are a value that can change, depending on information passed to the program.",
        "Let's see how to compare data! Would you want to see if 5 is greater than 4? Lets see how we can use conditional statements!",
        "Lets see how we can organize and condense Code! Functions help developers organize and section code!",
        "Let's see how we can store many pieces of information in one place! Lists allow you to store many types of data in just one variable!",
        "Lets see how we can break down code to solve complex problems! Recursion is when we repeat functions and solve really cool problems!"
    ]
    //globals
    var navTitle = "S̷͕̱͍̮͖̙̮̼̙̥̟͍̏̎̊̒̏̔̔̄̐̀͑̑̈́̒͘͜͠͠w̶̳̗͙͖͝i̶̢̧̦̞̣̘̼̱̝̻̫̤̱̭̣̯̬͈̘̮͔͍̟̎͑̊͒̔̇̄́͗̿̇͐̀̐́̽͝͠f̴̧̗̠̭͕͇̫̲̣̥̪̝̠̟̩̮̫̈́̇̄̀͌̉̀̀̀̌̑̂̋͑͊̇͋̉̾͐̿̚͠-̵̡͎͉͍̖͖̘͔̺̲̜̪͇̬͈͚͊̄̈̔̂͛̆̐͛͑̇̏͂̎̂̉̐̋̒̆̉̌̚͘͠͝ͅç̷̛̬̣̖̣͎̼͙̼̬͖͉̫͉̤͓̲̎̒̎̓̉̉̈́̓͊͐͌͌́̂̽̄̋͒̓̕͘̕͝͠͝͝͠͠y̶̡̻̥̭͓̹͎͍̮̱̗͚̗̩͎̬͓̯̜̭͚̻̼̰̠̿̊̾̐͌̓̉̈̀́̒̿̓̋̈́̿͛͘͜͠ͅc̵̛̛̼͆̿̎̀̈́́͐̄̌̈́͊̾̒̈̾̕̕̚͜͜͝͝l̵̨̢̡̘̞͓̱͈̱̮̯͕̳̹̝͆͒̀͒͆̇̀̃̐̇̋̃͌̚͘͘̚͝͝͝ȏ̴̱͚͎̓̈́̓̓͗̃̃́̄̏̓́̂̓̅̈́͌͑͒̽͆̓̚̕͘̕͠͝͠p̵̧̢̧͕̘̰̦̼͎̻͔̲̅̊̈́͊̉͌́̂̒̈́̉̃̄̔̚͠͝͝ͅë̴̡̡͖̖̤͇̟̹̥͕͎́̀̎̉́̓̂̄̕̕̚̕͜͠͝͝͠͠ď̶̨̨͕͔͈̦̤̭̟͉̭̱̜̫̱͕̭͖̼̦̬͕̫͓̻̙̻̮̗͎̯͆̒̀́͌̀̎̾̿͊̾̐̈́̂̋̀̚͠͠ͅi̵̳̟͚̲̱̯̳̜̙̮̬̹͉̱̩̞̪͎̩̤͍̖̠̭̙̘̭͔̮̹͗͑̐̽̈́̓̽͛̚͝ͅa̵̡̧̨̨̡̲̮͎͓͍̝͇̥̻̰̬̖̗̤̝̻̣̭͚͉͚̠̩̅̃̑͑̃̈͗̎͐̇͐͌̊̄́̈́͒̾̀̍͘"
    var animator: UIDynamicAnimator?
    var index = 0
    
    //start config
    override func loadView() {
        title = "\(navTitle)"
        view = UIView()
        self.navigationItem.setHidesBackButton(true, animated:true)
        let imageView1 = UIImageView(image: UIImage(named: "Vectors@3x.png")!)
        imageView1.frame = CGRect(x: view.frame.midX-240, y: view.frame.midY-100, width: 900, height: 1100)
        view.addSubview(imageView1)
        index = Int.random(in: 0 ... 4)
        
    }
    
    override func viewDidLayoutSubviews() {
        //bug test
        guard animator == nil else { return }
        
        //timmy image declaration
        let imageName = UIImage(named: "TimAngry.png")
        let imageView = UIImageView(image: imageName!)
        imageView.frame = CGRect(x: -1000, y: 100, width: 396, height: 545)
        view.addSubview(imageView)
        
        //text declaration
        let imageText = UILabel()
        imageText.text = "We need your help!"
        imageText.sizeToFit()
        imageText.font = UIFont.preferredFont(forTextStyle: .body)
        imageText.frame = CGRect(x: -1000, y: 100, width: 400, height: 260)
        self.view.addSubview(imageText)
        
        
        // 1: split the message up into words
        let words = extraInDepth[index].components(separatedBy: " ")
        
        // 2: create an empty array of labels
        var labels = [UILabel]()
        
        // 3: convert each word into a label
        for (index, word) in words.enumerated() {
            let label = UILabel()
            label.font = UIFont.preferredFont(forTextStyle: .title1)
            
            // 4: position the labels one above the other
            label.center = CGPoint(x: view.frame.midX, y: 50 + CGFloat(30 * index))
            label.text = word
            label.sizeToFit()
            view.addSubview(label)
            
            
            labels.append(label)
        }
        
        // 5: create a gravity behaviour for our labels
        let gravity = UIGravityBehavior(items: labels)
        animator = UIDynamicAnimator(referenceView: view)
        animator?.addBehavior(gravity)
        
        // 6: create a collision behavior for our labels
        let collisions = UICollisionBehavior(items: labels)
        
        // 7: give some boundaries for the collisions
        collisions.translatesReferenceBoundsIntoBoundary = true
        animator?.addBehavior(collisions)
        animateNow(timC: imageView, text: imageText)
    }
    //animate items into existence
    func animateNow(timC: UIImageView, text: UILabel){
        //delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            UIView.animate(withDuration: 3.0) { //1
                timC.frame = CGRect(x: self.view.frame.midX-160, y: 100, width: 100, height: 148)
                text.center = CGPoint(x: self.view.frame.midX+145, y: 160)
            }
            //more delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                let detail = number3()
                self.navigationController?.pushViewController(detail, animated: true)
            }
            
        }
        
    }
    
}


//------------------------Section #3------------------------
class number3: UIViewController, UINavigationBarDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "k̶̥̚ñ̸̥̈́d̷̰̮̈͘͝j̷̪̑a̶̪̝͑̐́k̵̡̕s̶̰̉̌d̸̳̬͌̚͠"
        self.navigationItem.setHidesBackButton(true, animated:true)
        
        
    }
    //MARK: Globals
    let varField: UITextField = UITextField()
    let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
    let imageText = UILabel()
    let image = UIImage(named: "TimAngry.png")
    let image1 = UIImage(named: "TimHappy.png")
    let sploshes = UIImage(named: "Vectors@3x.png")
    var errorCounter = 0
    
    override func viewDidLayoutSubviews() {
        //MARK: UI Code
        let imageView = UIImageView(image: image!)
        imageView.frame = CGRect(x: view.frame.midX, y: 1, width: 100, height: 148)
        imageView.center = CGPoint(x: view.frame.midX, y: view.frame.midY-200)
        view.addSubview(imageView)
        
        let imageView1 = UIImageView(image: sploshes!)
        imageView1.frame = CGRect(x: view.frame.midX, y: 1, width: 1000, height: 1200)
        imageView1.center = CGPoint(x: view.frame.midX, y: view.frame.midY)
        view.addSubview(imageView1)
        
        imageText.text = "This app is being attacked by hackers!\nWe need your coding skills to\nget rid of the hackers!\n\nWhat value does this variable hold? \nvar number = 10"
        imageText.sizeToFit()
        imageText.font = UIFont.preferredFont(forTextStyle: .body)
        imageText.textAlignment = .center
        imageText.frame = CGRect(x: 100, y: 100, width: 300, height: 150)
        imageText.center = CGPoint(x: view.frame.midX, y: view.frame.midY-50)
        imageText.numberOfLines = 23
        self.view.addSubview(imageText)
        
        
        button.backgroundColor = .blue
        button.center = CGPoint(x: view.frame.midX, y: view.frame.midY+150)
        button.setTitle("Submit?", for: .normal)
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
        
        
        varField.frame = CGRect(x: 50,y: 70,width:  200,height: 30)
        varField.placeholder = "Type Of Variable"
        varField.backgroundColor = UIColor.lightGray
        varField.center = CGPoint(x: view.frame.midX, y: view.frame.midY+75)
        varField.textAlignment = .center
        varField.layer.cornerRadius = 5
        self.view.addSubview(varField)
        
        
        
    }
    @objc func buttonAction(sender: UIButton!) {
        
        if varField.text! == "10"{
            //correct
            let alert = UIAlertController(title: "Good Job!", message: "The number after the name of the variable is the value that variable holds!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Next Mission!", style: .default, handler: { (UIAlertAction) in
                
                let detail = number4()
                self.navigationController?.pushViewController(detail, animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            errorCounter += 1
            //cehcks if error counter < 5
            if errorCounter < 5{
                image
                let alert = UIAlertController(title: "Nope!", message: "Thats the wrong value! Remember to look at the number the variable is equal to.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Next!", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                varField.text = ""
            }
            else{
                let alert = UIAlertController(title: "The Hackers have won!", message: "We couldnt hold them back!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "We lost, try again", style: .default, handler: { (UIAlertAction) in
                    
                    let detail = start()
                    self.navigationController?.pushViewController(detail, animated: true)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}



//------------------------Section #4------------------------
class number4: UIViewController, UINavigationBarDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "s̴̟̔w̸͚̓if̴̢͝t̸̠͘-̶̼̋ċ̵͖yć̵͈lo̵̱͗p̵̻͋pdi̶̻̐a"
        self.navigationItem.setHidesBackButton(true, animated:true)
        
        
    }
    //MARK: Globals
    let varField: UITextField = UITextField()
    let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
    let imageText = UILabel()
    let image = UIImage(named: "TimHappy.png")
    let image1 = UIImage(named: "TimAngry.png")
    let sploshes = UIImage(named: "Vectors@3x.png")
    var imageView:UIImageView = UIImageView(image: UIImage(named: "TimHappy.png"))
    var errorCounter = 0
    
    override func viewDidLayoutSubviews() {
        //MARK: UI Code
        imageView = UIImageView(image: self.image!)
        imageView.frame = CGRect(x: view.frame.midX, y: 1, width: 100, height: 148)
        imageView.center = CGPoint(x: view.frame.midX, y: view.frame.midY-200)
        view.addSubview(imageView)
        let imageView1 = UIImageView(image: sploshes!)
        imageView1.frame = CGRect(x: view.frame.midX, y: 1, width: 1000, height: 1200)
        imageView1.center = CGPoint(x: view.frame.midX, y: view.frame.midY)
        view.addSubview(imageView1)
        
        imageText.text = "What type of data does this variable hold? \nvar text: String = 10"
        imageText.sizeToFit()
        imageText.font = UIFont.preferredFont(forTextStyle: .body)
        imageText.textAlignment = .center
        imageText.frame = CGRect(x: 100, y: 100, width: 400, height: 260)
        imageText.center = CGPoint(x: view.frame.midX, y: view.frame.midY-50)
        imageText.numberOfLines = 23
        self.view.addSubview(imageText)
        
        
        button.backgroundColor = .blue
        button.center = CGPoint(x: view.frame.midX, y: view.frame.midY+150)
        button.setTitle("Submit?", for: .normal)
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(button)
        
        
        varField.frame = CGRect(x: 50,y: 70,width:  200,height: 30)
        varField.placeholder = "Type Of Variable"
        varField.backgroundColor = UIColor.lightGray
        varField.center = CGPoint(x: view.frame.midX, y: view.frame.midY+75)
        varField.textAlignment = .center
        varField.layer.cornerRadius = 5
        self.view.addSubview(varField)
        
        
        
    }
    //button function
    @objc func buttonAction(sender: UIButton!) {
        
        if varField.text!.lowercased() == "string"{
            //correct
            let alert = UIAlertController(title: "Good Job!", message: "The thing after the name of the vairable is the type", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Next Mission!", style: .default, handler: { (UIAlertAction) in
                
                let detail = number5()
                self.navigationController?.pushViewController(detail, animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            errorCounter += 1
            //checks if error counter < 5
            if errorCounter < 5{
                let alert = UIAlertController(title: "Nope!", message: "Thats the wrong TYPE, remeber to look at the type of data the variable is holding.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Next!", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                varField.text = ""
            }
            else{
                imageView = UIImageView(image: UIImage(named: "TimAngry.png"))
                self.view.addSubview(imageText)
                let alert = UIAlertController(title: "The Hackers have won!", message: "We couldnt hold them back, Tim is sad now!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "We lost, try again", style: .default, handler: { (UIAlertAction) in
                    let detail = start()
                    self.navigationController?.pushViewController(detail, animated: true)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}


//------------------------Section #5------------------------
class number5: UIViewController, UINavigationBarDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "s̴̟̔w̸͚̓i̶̘̊f̴̢͝t̸̠͘-̶̼̋ċ̵͖y̷̘͐ć̵͈l̶͕̏o̵̱͗p̵̻͋ë̸̡́d̶̦̔i̶̻̐ȁ̸͙"
        self.navigationItem.setHidesBackButton(true, animated:true)
        
        
    }
    //MARK: Globals
    let varField: UITextField = UITextField()
    let button = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
    let imageText = UILabel()
    let image = UIImage(named: "TimHappy.png")
    let sploshes = UIImage(named: "Vectors@3x.png")
    var errorCounter = 0
    
    override func viewDidLayoutSubviews() {
        //MARK: UI Code
        let imageView = UIImageView(image: image!)
        imageView.frame = CGRect(x: view.frame.midX, y: 1, width: 100, height: 148)
        imageView.center = CGPoint(x: view.frame.midX, y: view.frame.midY-200)
        view.addSubview(imageView)
        
        
        let imageView1 = UIImageView(image: sploshes!)
        imageView1.frame = CGRect(x: view.frame.midX, y: 1, width: 1000, height: 1200)
        imageView1.center = CGPoint(x: view.frame.midX, y: view.frame.midY)
        view.addSubview(imageView1)
        
    
        
        imageText.text = "How can we declare a variable with a name 'num' and a value of 4?"
        imageText.sizeToFit()
        imageText.font = UIFont.preferredFont(forTextStyle: .body)
        imageText.textAlignment = .center
        imageText.frame = CGRect(x: 100, y: 100, width: 400, height: 260)
        imageText.center = CGPoint(x: view.frame.midX, y: view.frame.midY-50)
        imageText.numberOfLines = 23
        self.view.addSubview(imageText)
        
        
        button.backgroundColor = .blue
        button.center = CGPoint(x: view.frame.midX, y: view.frame.midY+150)
        button.setTitle("Submit?", for: .normal)
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button)
        
        
        varField.frame = CGRect(x: 50,y: 70,width:  200,height: 30)
        varField.placeholder = "Variable Syntax"
        varField.backgroundColor = UIColor.lightGray
        varField.center = CGPoint(x: view.frame.midX, y: view.frame.midY+75)
        varField.textAlignment = .center
        varField.layer.cornerRadius = 5
        self.view.addSubview(varField)
        
        
    }
    @objc func buttonAction(sender: UIButton!) {
        
        if varField.text!.lowercased() == "var num = 4" || varField.text!.lowercased() == "var num: Int = 4"{
            //got correct
            //alert init
            let alert = UIAlertController(title: "WE Beat Them!", message: "Thanks for everything you did! We beat the hackers!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Claim Your Prize", style: .default, handler: { (UIAlertAction) in
                
                let detail = Won()
                self.navigationController?.pushViewController(detail, animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else{
            errorCounter += 1
            //checks if error counter < 5
            if errorCounter < 5{
                let alert = UIAlertController(title: "Nope!", message: "Hm, try again. We want to declare a variable with a name num and a value of 4", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Next!", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                varField.text = ""
            }
            //hackers won :(
            else{
                //alert init
                let alert = UIAlertController(title: "The Hackers have won!", message: "We couldnt hold them back, Tim is sad now!", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "We lost, try again", style: .default, handler: { (UIAlertAction) in
                    let detail = start()
                    self.navigationController?.pushViewController(detail, animated: true)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}


//------------------------Section #6, final------------------------
class Won: UIViewController{
    override func viewDidLoad() {
        //outer layer image
        let imageView = UIImageView(image: UIImage(named: "Congrats.png"))
        imageView.frame = CGRect(x: 0, y: 0, width: 800, height: 1000)
        imageView.center = CGPoint(x: view.frame.midX-50, y: view.frame.midY)
        view.addSubview(imageView)
        
        //gift button image
        let image = UIImage(named: "Gift.png")
        
        let button = UIButton()
        button.frame = CGRect(x: 0, y: 0, width: 316.62, height: 243.57)
        button.setBackgroundImage(image, for: .normal)
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        button.center = CGPoint(x: view.frame.midX+5, y: view.frame.midY-110)
        
        self.view.addSubview(button)
    }
    //button action, object function
    @objc func buttonAction(){
        let alert = UIAlertController(title: "Prize", message: "Hi! If you would like to recive your prize, send an email to adamabughaida@gmail.com", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Will do!", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

//initial config
let master = start()
let nav = UINavigationController(rootViewController: master)
nav.preferredContentSize = CGSize(width: 500, height: 700)
PlaygroundPage.current.liveView = nav
